package Exceptions.Ariketa1.Ariketa4;

public class FractionException extends Exception {
    public FractionException(String s){
        super(s);

    }

}
